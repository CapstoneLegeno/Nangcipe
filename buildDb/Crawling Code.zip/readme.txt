나무위키 데이터 덤프
https://namu.wiki/w/%EB%82%98%EB%AC%B4%EC%9C%84%ED%82%A4:%EB%8D%B0%EC%9D%B4%ED%84%B0%EB%B2%A0%EC%9D%B4%EC%8A%A4%20%EB%8D%A4%ED%94%84


Python - requets / Beautiful Soup 사용



1. requests 로 html 코드를 얻어옴
 - \Crawling Code\requests\reqests.py

2. requests 에 html_pull.py 코드를 입력( 사이트 주소를 입력)

3. BeautifulSoup를 import 
 - \Crawling Code\BeautifulSoup\import.py

4. link_get을 통해 크롤링 웹페이지 가져오기

5. Textinfo를 통해 페이지내 크롤링할 텍스트 가져오기

6. webdata를 통해 크롤링된 텍스트를 데이터 프레임으로 정렬