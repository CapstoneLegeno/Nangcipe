from bs4 import BeautifulSoup

def crawl_cooking_recipe_page() :
 pages = []
 
 c = get_html('https://namu.wiki/w/%EC%9A%94%EB%A6%AC%EB%B2%95/%EC%A2%85%EB%A5%98')
 
 soup = BeautifulSoup(c)